This file contains the topology (.top) and coordinate (.gro) files used for the M3-exc simulations.
