The ZIP file this README.txt file was extracted from contains all files created or changed for the Martini3-exc forcefield.

The Martini3-exc interaction Matrix file is martini-exc_v3.0.0.itp.

The topologies of the trastuzumab and omalizumab Fab domains are in M3-exc_Trastuzumab_Fab.itp and M3-exc_Omalizumab_Fab.itp, respectively.

The topologies for the free amino acids, arginine and glutamate, are found in M3-exc_arginine.itp and M3-exc_glutamate.itp, respectively.

To convert a Martini3 .itp file for usage with Martini3-exc, ConvertM3TopolToM3-exc.ipynb is included. It is a file written and used with a jupyter notebook (python version 3.9). Note, that the names of the input and output files need to be changed.
